package com.example.myapplication

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationManagerCompat
import com.example.myapplication.database.CharacterDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CharacterDeleteReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val characterId = intent.getIntExtra("character_id", -1)

        if (characterId != -1) {
            CoroutineScope(Dispatchers.IO).launch {
                val characterDao = CharacterDatabase.getDatabase(context).characterDao()
                characterDao.deleteCharacter(characterId)
                Log.d("CharacterDeleteReceiver", "Personagem com ID $characterId excluído.")
            }

            // Cancelar a notificação
            val notificationId = intent.getIntExtra("notification_id", 0)
            NotificationManagerCompat.from(context).cancel(notificationId)
        } else {
            Log.e("CharacterDeleteReceiver", "ID do personagem inválido para exclusão.")
        }
    }
}
